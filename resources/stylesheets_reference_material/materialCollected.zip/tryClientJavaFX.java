/**
 * 
 */
package client;

//import java.io.File;

import mainEngine.MainEngine;
import javafx.application.Application;
import javafx.stage.Stage;


/**
 * A simple client to process a folder.
 * 
 * @author pvassil
 * @since 2019-06-10
 * @version v.0.4
 */
public class tryClientJavaFX extends Application{

	/**
	 * A simple client to process a folder.
	 * Assume you have the project <code>PRJ</code> its should contain a folder <code>PRJ/results</code> with the output of Hecate.
	 * You should pass the <code>PRJ</code> as the parameter needed at args[0] (without a final "/" at the end)
	 *
	 * @param args the first parameter given should be the path of the results of Hecate. 
	 * 
	 */
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		String folderOfProject = "resources/Egee";
		//File folderToProcess = new File(folderOfHecateResults);
		
		MainEngine engine = new MainEngine(folderOfProject, primaryStage);
		engine.processFolder();
		
		System.out.println("Done with " + folderOfProject);		
	}

}
