package chartexport;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

public class LineChartRanging extends Application {

    @Override public void start(Stage stage) {
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Number of Month");
        final LineChart<Number,Number> lineChart =
                new LineChart<>(xAxis, yAxis);

        XYChart.Series series = new XYChart.Series();
        series.setName("My portfolio");
        series.getData().add(new XYChart.Data(1, 2317));
        series.getData().add(new XYChart.Data(2, 1427));
        series.getData().add(new XYChart.Data(3, 1573));
        series.getData().add(new XYChart.Data(4, 2452));
        series.getData().add(new XYChart.Data(5, 3495));
        series.getData().add(new XYChart.Data(6, 3663));
        series.getData().add(new XYChart.Data(7, 2215));
        series.getData().add(new XYChart.Data(8, 4541));
        series.getData().add(new XYChart.Data(9, 4393));
        series.getData().add(new XYChart.Data(10, 1772));
        series.getData().add(new XYChart.Data(11, 2994));
        series.getData().add(new XYChart.Data(12, 2508));

        Scene scene  = new Scene(lineChart);
        lineChart.getData().add(series);
        lineChart.setPrefSize(500, 340);

        yAxis.setAutoRanging(false);
        yAxis.setLowerBound(1000);
        yAxis.setUpperBound(5000);
        yAxis.setTickUnit(500);
        yAxis.setMinorTickVisible(false);

        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
	public static void main(String[] args) {
		launch(args);
	}
}